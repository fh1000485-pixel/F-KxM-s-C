package ntgcalls

//#include "ntgcalls.h"
//#include <stdlib.h>
//extern void handleStreamEnd(uintptr_t ptr, int64_t chatID, ntg_stream_type_enum streamType, ntg_stream_device_enum streamDevice, void*);
//extern void handleUpgrade(uintptr_t ptr, int64_t chatID, ntg_media_state_struct state, void*);
//extern void handleConnectionChange(uintptr_t ptr, int64_t chatID, ntg_network_info_struct networkInfo, void*);
//extern void handleSignal(uintptr_t ptr, int64_t chatID, uint8_t*, int, void*);
//extern void handleFrames(uintptr_t ptr, int64_t chatID, ntg_stream_mode_enum streamMode, ntg_stream_device_enum streamDevice, ntg_frame_struct* frames, int size, void*);
//extern void handleRemoteSourceChange(uintptr_t ptr, int64_t chatID, ntg_remote_source_struct remoteSource, void*);
//extern void handleRequestBroadcastTimestamp(uintptr_t ptr, int64_t chatID, void*);
//extern void handleRequestBroadcastPart(uintptr_t ptr, int64_t chatID, ntg_segment_part_request_struct segmentPartRequest, void*);
//extern void handleLogs(ntg_log_message_struct logMessage);
import "C"

import (
	"fmt"
	"runtime"
	"sync"
	"unsafe"

	"KanhaMusic/kanha/logger"
)

var clientRegistry = struct {
	sync.RWMutex
	clients map[uintptr]*Client
}{clients: make(map[uintptr]*Client)}

func init() {
	C.ntg_register_logger(
		C.ntg_log_message_callback(unsafe.Pointer(C.handleLogs)),
	)
	// The C++ engine logs extremely verbosely; surface only errors.
	logger.GetLogger("ntgcalls").SetLevel(logger.ErrorLevel)
	logger.GetLogger("webrtc").SetLevel(logger.ErrorLevel)
}

func NTgCalls() *Client {
	instance := &Client{
		ptr: uintptr(C.ntg_init()),
	}

	clientRegistry.Lock()
	clientRegistry.clients[instance.ptr] = instance
	clientRegistry.Unlock()

	userDataToken := unsafe.Pointer(instance.ptr)

	C.ntg_on_stream_end(
		C.uintptr_t(instance.ptr),
		C.ntg_stream_callback(unsafe.Pointer(C.handleStreamEnd)),
		userDataToken,
	)
	C.ntg_on_upgrade(
		C.uintptr_t(instance.ptr),
		C.ntg_upgrade_callback(unsafe.Pointer(C.handleUpgrade)),
		userDataToken,
	)
	C.ntg_on_signaling_data(
		C.uintptr_t(instance.ptr),
		C.ntg_signaling_callback(unsafe.Pointer(C.handleSignal)),
		userDataToken,
	)
	C.ntg_on_connection_change(
		C.uintptr_t(instance.ptr),
		C.ntg_connection_callback(unsafe.Pointer(C.handleConnectionChange)),
		userDataToken,
	)
	C.ntg_on_frames(
		C.uintptr_t(instance.ptr),
		C.ntg_frame_callback(unsafe.Pointer(C.handleFrames)),
		userDataToken,
	)
	C.ntg_on_remote_source_change(
		C.uintptr_t(instance.ptr),
		C.ntg_remote_source_callback(
			unsafe.Pointer(C.handleRemoteSourceChange),
		),
		userDataToken,
	)
	C.ntg_on_request_broadcast_timestamp(
		C.uintptr_t(instance.ptr),
		C.ntg_broadcast_timestamp_callback(
			unsafe.Pointer(C.handleRequestBroadcastTimestamp),
		),
		userDataToken,
	)
	C.ntg_on_request_broadcast_part(
		C.uintptr_t(instance.ptr),
		C.ntg_broadcast_part_callback(
			unsafe.Pointer(C.handleRequestBroadcastPart),
		),
		userDataToken,
	)

	runtime.SetFinalizer(instance, func(c *Client) {
		if c.ptr != 0 {
			c.Free()
		}
	})
	return instance
}

//export handleLogs
func handleLogs(logMessage C.ntg_log_message_struct) {
	message := fmt.Sprintf(
		"(%s:%d) %s",
		string(C.GoString(logMessage.file)),
		uint32(logMessage.line),
		string(C.GoString(logMessage.message)),
	)
	var loggerName string
	if logMessage.source == C.NTG_LOG_WEBRTC {
		loggerName = "webrtc"
	} else {
		loggerName = "ntgcalls"
	}
	loggerInstance := logger.GetLogger(loggerName)
	switch logMessage.level {
	case C.NTG_LOG_DEBUG:
		loggerInstance.Debug(message)
	case C.NTG_LOG_INFO:
		loggerInstance.Info(message)
	case C.NTG_LOG_WARNING:
		loggerInstance.Warn(message)
	case C.NTG_LOG_ERROR:
		loggerInstance.Error(message)
	}
}

//
//export handleStreamEnd
func handleStreamEnd(
	_ C.uintptr_t,
	chatID C.int64_t,
	streamType C.ntg_stream_type_enum,
	streamDevice C.ntg_stream_device_enum,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	var goStreamType StreamType
	if streamType == C.NTG_STREAM_AUDIO {
		goStreamType = AudioStream
	} else {
		goStreamType = VideoStream
	}
	goStreamDevice := parseStreamDevice(streamDevice)

	callbacks := self.getStreamEndCallbacks()
	for _, callback := range callbacks {
		go callback(goChatID, goStreamType, goStreamDevice)
	}
}

//
//export handleUpgrade
func handleUpgrade(
	_ C.uintptr_t,
	chatID C.int64_t,
	state C.ntg_media_state_struct,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	goState := MediaState{
		Muted:              bool(state.muted),
		VideoPaused:        bool(state.videoPaused),
		VideoStopped:       bool(state.videoStopped),
		PresentationPaused: bool(state.presentationPaused),
	}

	callbacks := self.getUpgradeCallbacks()
	for _, callback := range callbacks {
		go callback(goChatID, goState)
	}
}

//
//export handleSignal
func handleSignal(
	_ C.uintptr_t,
	chatID C.int64_t,
	data *C.uint8_t,
	size C.int,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	goData := C.GoBytes(unsafe.Pointer(data), size)

	callbacks := self.getSignalCallbacks()
	for _, callback := range callbacks {
		dataCopy := make([]byte, len(goData))
		copy(dataCopy, goData)
		go callback(goChatID, dataCopy)
	}
}

//
//export handleConnectionChange
func handleConnectionChange(
	_ C.uintptr_t,
	chatID C.int64_t,
	networkInfo C.ntg_network_info_struct,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	var goCallState NetworkInfo
	switch networkInfo.kind {
	case C.NTG_KIND_NORMAL:
		goCallState.Kind = NormalConnection
	case C.NTG_KIND_PRESENTATION:
		goCallState.Kind = PresentationConnection
	}
	goCallState.State = parseConnectionState(networkInfo.state)

	callbacks := self.getConnectionChangeCallbacks()
	for _, callback := range callbacks {
		go callback(goChatID, goCallState)
	}
}

//
//export handleFrames
func handleFrames(
	_ C.uintptr_t,
	chatID C.int64_t,
	streamMode C.ntg_stream_mode_enum,
	streamDevice C.ntg_stream_device_enum,
	frames *C.ntg_frame_struct,
	size C.int,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	var goStreamMode StreamMode
	switch streamMode {
	case C.NTG_STREAM_CAPTURE:
		goStreamMode = CaptureStream
	case C.NTG_STREAM_PLAYBACK:
		goStreamMode = PlaybackStream
	}
	goStreamDevice := parseStreamDevice(streamDevice)

	rawFrames := make([]Frame, size)
	for i := 0; i < int(size); i++ {
		rawFrame := *(*C.ntg_frame_struct)(unsafe.Pointer(uintptr(unsafe.Pointer(frames)) + uintptr(i)*unsafe.Sizeof(C.ntg_frame_struct{})))

		frameData := C.GoBytes(unsafe.Pointer(rawFrame.data), rawFrame.sizeData)

		rawFrames[i] = Frame{
			Ssrc: uint32(rawFrame.ssrc),
			Data: frameData,
			FrameData: FrameData{
				AbsoluteCaptureTimestampMs: int64(
					rawFrame.frameData.absoluteCaptureTimestampMs,
				),
				Width:    uint16(rawFrame.frameData.width),
				Height:   uint16(rawFrame.frameData.height),
				Rotation: uint16(rawFrame.frameData.rotation),
			},
		}
	}

	callbacks := self.getFrameCallbacks()
	for _, callback := range callbacks {
		framesCopy := make([]Frame, len(rawFrames))
		copy(framesCopy, rawFrames)
		go callback(goChatID, goStreamMode, goStreamDevice, framesCopy)
	}
}

//
//export handleRemoteSourceChange
func handleRemoteSourceChange(
	_ C.uintptr_t,
	chatID C.int64_t,
	remoteSource C.ntg_remote_source_struct,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	goRemoteSource := RemoteSource{
		Ssrc:   uint32(remoteSource.ssrc),
		State:  parseStreamStatus(remoteSource.state),
		Device: parseStreamDevice(remoteSource.device),
	}

	callbacks := self.getRemoteSourceCallbacks()
	for _, callback := range callbacks {
		go callback(goChatID, goRemoteSource)
	}
}

//
//export handleRequestBroadcastTimestamp
func handleRequestBroadcastTimestamp(
	_ C.uintptr_t,
	chatID C.int64_t,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	callbacks := self.getBroadcastTimestampCallbacks()
	for _, callback := range callbacks {
		go callback(goChatID)
	}
}

//
//export handleRequestBroadcastPart
func handleRequestBroadcastPart(
	_ C.uintptr_t,
	chatID C.int64_t,
	segmentPartRequest C.ntg_segment_part_request_struct,
	userData unsafe.Pointer,
) {
	self := getClientFromUserData(userData)
	if self == nil {
		return
	}

	goChatID := int64(chatID)
	var goSegmentQuality MediaSegmentQuality
	switch segmentPartRequest.quality {
	case C.NTG_MEDIA_SEGMENT_QUALITY_NONE:
		goSegmentQuality = SegmentQualityNone
	case C.NTG_MEDIA_SEGMENT_QUALITY_THUMBNAIL:
		goSegmentQuality = SegmentQualityThumbnail
	case C.NTG_MEDIA_SEGMENT_QUALITY_MEDIUM:
		goSegmentQuality = SegmentQualityMedium
	case C.NTG_MEDIA_SEGMENT_QUALITY_FULL:
		goSegmentQuality = SegmentQualityFull
	}

	goSegmentPartRequest := SegmentPartRequest{
		SegmentID:     int64(segmentPartRequest.segmentId),
		PartID:        int32(segmentPartRequest.partId),
		Limit:         int32(segmentPartRequest.limit),
		Timestamp:     int64(segmentPartRequest.timestamp),
		QualityUpdate: bool(segmentPartRequest.qualityUpdate),
		ChannelID:     int32(segmentPartRequest.channelId),
		Quality:       goSegmentQuality,
	}

	callbacks := self.getBroadcastPartCallbacks()
	for _, callback := range callbacks {
		go callback(goChatID, goSegmentPartRequest)
	}
}

func (ctx *Client) GetState(chatId int64) (MediaState, error) {
	f := CreateFuture()
	var buffer C.ntg_media_state_struct
	C.ntg_get_state(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		&buffer,
		f.ParseToC(),
	)
	f.wait()
	err := parseErrorCode(f)
	if err != nil {
		return MediaState{}, err
	}
	return MediaState{
		Muted:              bool(buffer.muted),
		VideoPaused:        bool(buffer.videoPaused),
		VideoStopped:       bool(buffer.videoStopped),
		PresentationPaused: bool(buffer.presentationPaused),
	}, nil
}

func (ctx *Client) GetConnectionMode(chatId int64) (ConnectionMode, error) {
	f := CreateFuture()
	var buffer C.ntg_connection_mode_enum
	C.ntg_get_connection_mode(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		&buffer,
		f.ParseToC(),
	)
	f.wait()
	err := parseErrorCode(f)
	if err != nil {
		return ConnectionMode(0), err
	}
	switch buffer {
	case C.NTG_CONNECTION_MODE_RTC:
		return RtcConnection, nil
	case C.NTG_CONNECTION_MODE_STREAM:
		return StreamConnection, nil
	case C.NTG_CONNECTION_MODE_RTMP:
		return RTMPConnection, nil
	default:
		return ConnectionMode(0), fmt.Errorf("unknown connection mode")
	}
}

func (ctx *Client) CreateCall(chatId int64) (string, error) {
	var buffer *C.char
	f := CreateFuture()
	C.ntg_create(C.uintptr_t(ctx.ptr), C.int64_t(chatId), &buffer, f.ParseToC())
	f.wait()
	defer C.free(unsafe.Pointer(buffer))
	return C.GoString(buffer), parseErrorCode(f)
}

func (ctx *Client) InitPresentation(chatId int64) (string, error) {
	var buffer *C.char
	f := CreateFuture()
	C.ntg_init_presentation(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		&buffer,
		f.ParseToC(),
	)
	f.wait()
	defer C.free(unsafe.Pointer(buffer))
	return C.GoString(buffer), parseErrorCode(f)
}

func (ctx *Client) StopPresentation(chatId int64) error {
	f := CreateFuture()
	C.ntg_stop_presentation(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		f.ParseToC(),
	)
	f.wait()
	return parseErrorCode(f)
}

func (ctx *Client) AddIncomingVideo(
	chatId int64,
	endpoint string,
	ssrcGroups []SsrcGroup,
) (uint32, error) {
	buffer := new(C.uint32_t)
	f := CreateFuture()
	endpointC := C.CString(endpoint)
	ssrcGroupsC := parseSsrcGroups(ssrcGroups)
	C.ntg_add_incoming_video(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		endpointC,
		ssrcGroupsC,
		C.int(len(ssrcGroups)),
		buffer,
		f.ParseToC(),
	)
	f.wait()
	C.free(unsafe.Pointer(endpointC))
	freeSsrcGroups(ssrcGroupsC, C.int(len(ssrcGroups)))
	return uint32(*buffer), parseErrorCode(f)
}

func (ctx *Client) RemoveIncomingVideo(chatId int64, endpoint string) error {
	f := CreateFuture()
	endpointC := C.CString(endpoint)
	C.ntg_remove_incoming_video(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		endpointC,
		f.ParseToC(),
	)
	f.wait()
	C.free(unsafe.Pointer(endpointC))
	return parseErrorCode(f)
}

func (ctx *Client) CreateP2PCall(chatId int64) error {
	f := CreateFuture()
	C.ntg_create_p2p(C.uintptr_t(ctx.ptr), C.int64_t(chatId), f.ParseToC())
	f.wait()
	return parseErrorCode(f)
}

func (ctx *Client) InitExchange(
	chatId int64,
	dhConfig DhConfig,
	gAHash []byte,
) ([]byte, error) {
	var buffer *C.uint8_t
	var size C.int
	gAHashC, gAHashSize := parseBytes(gAHash)
	dhConfigC := dhConfig.ParseToC()
	f := CreateFuture()
	C.ntg_init_exchange(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		&dhConfigC,
		gAHashC,
		gAHashSize,
		&buffer,
		&size,
		f.ParseToC(),
	)
	f.wait()
	defer C.free(unsafe.Pointer(buffer))
	defer C.free(unsafe.Pointer(gAHashC))
	defer freeDhConfig(&dhConfigC)
	return C.GoBytes(unsafe.Pointer(buffer), size), parseErrorCode(f)
}

func (ctx *Client) ExchangeKeys(
	chatId int64,
	gAB []byte,
	fingerprint int64,
) (AuthParams, error) {
	f := CreateFuture()
	var buffer C.ntg_auth_params_struct
	gABC, gABSize := parseBytes(gAB)
	C.ntg_exchange_keys(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		gABC,
		gABSize,
		C.int64_t(fingerprint),
		&buffer,
		f.ParseToC(),
	)
	f.wait()
	defer C.free(unsafe.Pointer(gABC))
	defer C.free(unsafe.Pointer(buffer.g_a_or_b))
	return AuthParams{
		GAOrB: C.GoBytes(
			unsafe.Pointer(buffer.g_a_or_b),
			buffer.sizeGAB,
		),
		KeyFingerprint: int64(buffer.key_fingerprint),
	}, parseErrorCode(f)
}

func (ctx *Client) SkipExchange(
	chatId int64,
	encryptionKey []byte,
	isOutgoing bool,
) error {
	f := CreateFuture()
	encryptionKeyC, encryptionKeySize := parseBytes(encryptionKey)
	C.ntg_skip_exchange(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		encryptionKeyC,
		encryptionKeySize,
		C.bool(isOutgoing),
		f.ParseToC(),
	)
	f.wait()
	defer C.free(unsafe.Pointer(encryptionKeyC))
	return parseErrorCode(f)
}

func (ctx *Client) ConnectP2P(
	chatId int64,
	rtcServers []RTCServer,
	versions []string,
	P2PAllowed bool,
) error {
	f := CreateFuture()
	versionsC, sizeVersions := parseStringVectorC(versions)
	rtcServersC := parseRtcServers(rtcServers)
	C.ntg_connect_p2p(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		rtcServersC,
		C.int(len(rtcServers)),
		versionsC,
		C.int(sizeVersions),
		C.bool(P2PAllowed),
		f.ParseToC(),
	)
	f.wait()
	freeStringVectorC(versionsC, sizeVersions)
	freeRtcServers(rtcServersC, C.int(len(rtcServers)))
	return parseErrorCode(f)
}

func (ctx *Client) SendSignalingData(chatId int64, data []byte) error {
	f := CreateFuture()
	dataC, dataSize := parseBytes(data)
	C.ntg_send_signaling_data(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		dataC,
		dataSize,
		f.ParseToC(),
	)
	f.wait()
	defer C.free(unsafe.Pointer(dataC))
	return parseErrorCode(f)
}

//goland:noinspection GoUnusedExportedFunction
func GetProtocol() Protocol {
	var buffer C.ntg_protocol_struct
	C.ntg_get_protocol(&buffer)
	return Protocol{
		MinLayer:     int32(buffer.minLayer),
		MaxLayer:     int32(buffer.maxLayer),
		UdpP2P:       bool(buffer.udpP2P),
		UdpReflector: bool(buffer.udpReflector),
		Versions: parseStringVector(
			unsafe.Pointer(buffer.libraryVersions),
			buffer.libraryVersionsSize,
		),
	}
}

func (ctx *Client) Connect(
	chatId int64,
	params string,
	isPresentation bool,
) error {
	f := CreateFuture()
	paramsC := C.CString(params)
	C.ntg_connect(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		paramsC,
		C.bool(isPresentation),
		f.ParseToC(),
	)
	f.wait()
	C.free(unsafe.Pointer(paramsC))
	return parseErrorCode(f)
}

func (ctx *Client) SetStreamSources(
	chatId int64,
	streamMode StreamMode,
	desc MediaDescription,
) error {
	f := CreateFuture()
	cDesc := desc.ParseToC()
	defer freeMediaDescriptionC(cDesc)

	C.ntg_set_stream_sources(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		streamMode.ParseToC(),
		cDesc,
		f.ParseToC(),
	)
	f.wait()
	return parseErrorCode(f)
}

func (ctx *Client) SendExternalFrame(
	chatId int64,
	streamDevice StreamDevice,
	data []byte,
	frameData FrameData,
) error {
	f := CreateFuture()
	dataC, dataSize := parseBytes(data)
	C.ntg_send_external_frame(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		streamDevice.ParseToC(),
		dataC,
		dataSize,
		frameData.ParseToC(),
		f.ParseToC(),
	)
	f.wait()
	defer C.free(unsafe.Pointer(dataC))
	return parseErrorCode(f)
}

func (ctx *Client) SendBroadcastTimestamp(chatId, timestamp int64) error {
	f := CreateFuture()
	C.ntg_send_broadcast_timestamp(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		C.int64_t(timestamp),
		f.ParseToC(),
	)
	f.wait()
	return parseErrorCode(f)
}

func (ctx *Client) SendBroadcastPart(
	chatId, segmentID int64,
	partID int32,
	status MediaSegmentStatus,
	qualityUpdate bool,
	data []byte,
) error {
	f := CreateFuture()
	dataC, dataSize := parseBytes(data)
	C.ntg_send_broadcast_part(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		C.int64_t(segmentID),
		C.int32_t(partID),
		status.ParseToC(),
		C.bool(qualityUpdate),
		dataC,
		dataSize,
		f.ParseToC(),
	)
	f.wait()
	defer C.free(unsafe.Pointer(dataC))
	return parseErrorCode(f)
}

func (ctx *Client) Pause(chatId int64) (bool, error) {
	f := CreateFuture()
	C.ntg_pause(C.uintptr_t(ctx.ptr), C.int64_t(chatId), f.ParseToC())
	f.wait()
	return parseBool(f)
}

func (ctx *Client) Resume(chatId int64) (bool, error) {
	f := CreateFuture()
	C.ntg_resume(C.uintptr_t(ctx.ptr), C.int64_t(chatId), f.ParseToC())
	f.wait()
	return parseBool(f)
}

func (ctx *Client) Mute(chatId int64) (bool, error) {
	f := CreateFuture()
	C.ntg_mute(C.uintptr_t(ctx.ptr), C.int64_t(chatId), f.ParseToC())
	f.wait()
	return parseBool(f)
}

func (ctx *Client) Unmute(chatId int64) (bool, error) {
	f := CreateFuture()
	C.ntg_unmute(C.uintptr_t(ctx.ptr), C.int64_t(chatId), f.ParseToC())
	f.wait()
	return parseBool(f)
}

func (ctx *Client) Stop(chatId int64) error {
	f := CreateFuture()
	C.ntg_stop(C.uintptr_t(ctx.ptr), C.int64_t(chatId), f.ParseToC())
	f.wait()
	return parseErrorCode(f)
}

func (ctx *Client) Time(chatId int64, streamMode StreamMode) (uint64, error) {
	f := CreateFuture()
	var buffer C.int64_t
	C.ntg_time(
		C.uintptr_t(ctx.ptr),
		C.int64_t(chatId),
		streamMode.ParseToC(),
		&buffer,
		f.ParseToC(),
	)
	f.wait()
	return uint64(buffer), parseErrorCode(f)
}

//goland:noinspection GoUnusedExportedFunction
func GetMediaDevices() MediaDevices {
	var buffer C.ntg_media_devices_struct
	C.ntg_get_media_devices(&buffer)
	return MediaDevices{
		Microphone: parseDeviceInfoVector(
			unsafe.Pointer(buffer.microphone),
			buffer.sizeMicrophone,
		),
		Speaker: parseDeviceInfoVector(
			unsafe.Pointer(buffer.speaker),
			buffer.sizeSpeaker,
		),
		Camera: parseDeviceInfoVector(
			unsafe.Pointer(buffer.camera),
			buffer.sizeCamera,
		),
		Screen: parseDeviceInfoVector(
			unsafe.Pointer(buffer.screen),
			buffer.sizeScreen,
		),
	}
}

func (ctx *Client) CpuUsage() (float64, error) {
	f := CreateFuture()
	var buffer C.double
	C.ntg_cpu_usage(C.uintptr_t(ctx.ptr), &buffer, f.ParseToC())
	f.wait()
	return float64(buffer), parseErrorCode(f)
}

func (ctx *Client) EnableGLibLoop(enable bool) {
	C.ntg_enable_g_lib_loop(C.bool(enable))
}

func (ctx *Client) Calls() map[int64]*CallInfo {
	mapReturn := make(map[int64]*CallInfo)
	f := CreateFuture()
	var buffer *C.ntg_call_info_struct
	var size C.int
	C.ntg_calls(C.uintptr_t(ctx.ptr), &buffer, &size, f.ParseToC())
	f.wait()
	for i := 0; i < int(size); i++ {
		rawCall := *(*C.ntg_call_info_struct)(unsafe.Pointer(uintptr(unsafe.Pointer(buffer)) + uintptr(i)*unsafe.Sizeof(C.ntg_call_info_struct{})))
		mapReturn[int64(rawCall.chatId)] = &CallInfo{
			Playback: parseStreamStatus(rawCall.playback),
			Capture:  parseStreamStatus(rawCall.capture),
		}
	}
	defer C.free(unsafe.Pointer(buffer))
	return mapReturn
}

//goland:noinspection GoUnusedExportedFunction
func Version() string {
	var buffer *C.char
	C.ntg_get_version(&buffer)
	defer C.free(unsafe.Pointer(buffer))
	return C.GoString(buffer)
}

func (ctx *Client) Free() {
	if ctx.ptr == 0 {
		return
	}

	C.ntg_destroy(C.uintptr_t(ctx.ptr))

	clientRegistry.Lock()
	delete(clientRegistry.clients, ctx.ptr)
	clientRegistry.Unlock()

	ctx.ptr = 0
}

func getClientFromUserData(userData unsafe.Pointer) *Client {
	if userData == nil {
		return nil
	}

	ptr := uintptr(userData)

	clientRegistry.RLock()
	client := clientRegistry.clients[ptr]
	clientRegistry.RUnlock()

	return client
}
