/*
 * ● KanhaMusic
 * ○ A high-performance engine for streaming music in Telegram voicechats.
 *
 * Copyright (C) 2026 Kanha
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * Repository: https://github.com/Oyekanhaa/KanhaMusic
 */

package main

import (
	"fmt"
	"os/exec"
)

func checkDependencies() error {
	for _, bin := range []string{
		"ffmpeg",
		"ffprobe",
		"yt-dlp",
	} {
		if _, err := exec.LookPath(bin); err != nil {
			return fmt.Errorf(
				"required dependency %q was not found in your PATH; "+
					"please install %s and ensure it is accessible from PATH before starting KanhaMusic",
				bin,
				bin,
			)
		}
	}
	return nil
}
