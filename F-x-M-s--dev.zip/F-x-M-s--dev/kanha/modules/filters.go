/*
 * ● KanhaMusic
 * ○ A high-performance engine for streaming music in Telegram voicechats.
 *
 * Copyright (C) 2026 Kanha
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * Repository: https://github.com/Oyekanhaa/KanhaMusic
 */

package modules

import (
	"strings"

	td "github.com/Kanha/Meow"

	"KanhaMusic/config"
	"KanhaMusic/kanha/database"
	"KanhaMusic/kanha/logger"
	"KanhaMusic/kanha/utils"
)

func getCommand(m *td.Message) string {
	parts := strings.Fields(m.Text())
	if len(parts) == 0 {
		return ""
	}
	cmd, _, _ := strings.Cut(parts[0], "@")
	return cmd
}

func checkSudo(c *td.Client, m *td.Message) bool {
	if !isOwnerOrSudo(m.SenderID()) {
		if _, err := m.ReplyText(c, F(m.ChatID(), "only_sudo"), nil); err != nil {
			logger.Error(err)
		}
		return false
	}
	return true
}

func checkOwner(c *td.Client, m *td.Message) bool {
	if config.OwnerID == 0 || m.SenderID() != config.OwnerID {
		if _, err := m.ReplyText(c, F(m.ChatID(), "only_owner"), nil); err != nil {
			logger.Error(err)
		}
		return false
	}
	return true
}

func isSuperGroup(c *td.Client, m *td.Message) bool {
	if m.IsPrivate() {
		if _, err := m.ReplyText(c, F(m.ChatID(), "only_supergroup"), nil); err != nil {
			logger.Error(err)
		}
		database.AddServedUser(m.ChatID())
		return false
	}

	chat, err := m.GetChat(c)
	if err != nil {
		return false
	}

	sg, ok := chat.Type.(*td.ChatTypeSupergroup)
	if !ok || sg.IsChannel {
		return false
	}

	database.AddServedChat(m.ChatID())
	return true
}

func filterAuthUsers(c *td.Client, m *td.Message) bool {
	if canUseAdminCommand(c, m.ChatID(), m.SenderID()) {
		return true
	}

	mode, err := database.GetAdminMode(m.ChatID())
	if err == nil && mode == database.AdminModeAdminsOnly {
		if _, err := m.ReplyText(c, F(m.ChatID(), "only_admin"), nil); err != nil {
			logger.Error(err)
		}
	} else {
		if _, err := m.ReplyText(c, F(m.ChatID(), "only_admin_or_auth"), nil); err != nil {
			logger.Error(err)
		}
	}
	return false
}

func canUseAdminCommand(c *td.Client, chatID, userID int64) bool {
	if isOwnerOrSudo(userID) {
		return true
	}

	mode, err := database.GetAdminMode(chatID)
	if err != nil {
		mode = database.AdminModeAdminAuth
	}

	if mode == database.AdminModeEveryone {
		return true
	}

	isAdmin, err := utils.IsChatAdmin(c, chatID, userID)
	if err == nil && isAdmin {
		return true
	}

	if mode == database.AdminModeAdminsOnly {
		return false
	}

	isAuth, err := database.IsAuthorized(chatID, userID)
	return err == nil && isAuth
}

func isOwnerOrSudo(userID int64) bool {
	if config.OwnerID != 0 && userID == config.OwnerID {
		return true
	}
	isSudo, err := database.IsSudo(userID)
	return err == nil && isSudo
}
