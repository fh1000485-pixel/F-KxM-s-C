/*
 * ● KanhaMusic
 * ○ A high-performance engine for streaming music in Telegram voicechats.
 *
 * Copyright (C) 2026 Kanha
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * Repository: https://github.com/Oyekanhaa/KanhaMusic
 */

package locales

import (
	"embed"
	"fmt"
	"path"
	"sort"
	"strings"

	"KanhaMusic/kanha/logger"

	"gopkg.in/yaml.v3"

	"KanhaMusic/config"
)

//go:embed *.yml
var localesFS embed.FS

var loadedLocales = make(map[string]map[string]string)

const baseLang = "en"

type Arg map[string]any

func Load() error {
	files, err := localesFS.ReadDir(".")
	if err != nil {
		return fmt.Errorf("read locales dir: %w", err)
	}

	for _, f := range files {
		if f.IsDir() {
			continue
		}

		lang := strings.TrimSuffix(f.Name(), path.Ext(f.Name()))

		data, err := localesFS.ReadFile(f.Name())
		if err != nil {
			return fmt.Errorf("read locale %s: %w", f.Name(), err)
		}

		var locale map[string]string
		if err := yaml.Unmarshal(data, &locale); err != nil {
			return fmt.Errorf("parse locale %s: %w", f.Name(), err)
		}

		loadedLocales[lang] = locale
	}

	if _, ok := loadedLocales[config.DefaultLang]; !ok {
		return fmt.Errorf("default language %s not found", config.DefaultLang)
	}

	return nil
}

func Get(lang, key string, values Arg) string {
	tryLangs := []string{
		lang,
		config.DefaultLang,
		baseLang,
	}

	var val string
	var found bool

	for _, l := range tryLangs {
		if locale, ok := loadedLocales[l]; ok {
			if v, ok := locale[key]; ok {
				val = v
				found = true
				break
			}
		}
	}

	if !found {
		logger.Errorf("Missing translation → lang=%s key=%s", lang, key)

		return fmt.Sprintf("[%s]", key)
	}

	for k, v := range values {
		val = strings.ReplaceAll(val, "{"+k+"}", fmt.Sprint(v))
	}

	return expandEmojis(val)
}

func GetAvailableLanguages() []string {
	langs := make([]string, 0, len(loadedLocales))

	for lang := range loadedLocales {
		langs = append(langs, lang)
	}

	sort.Strings(langs)
	return langs
}
