/*
 * ● KanhaMusic
 * ○ A high-performance engine for streaming music in Telegram voicechats.
 *
 * Copyright (C) 2026 Kanha
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software Foundation,
 * either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * Repository: https://github.com/Oyekanhaa/KanhaMusic
 */

package database

import (
	"fmt"

	"go.mongodb.org/mongo-driver/v2/bson"
	"go.mongodb.org/mongo-driver/v2/mongo"
)

type ChatSettings struct {
	ChatID                int64     `bson:"_id"`
	ChannelPlayID         int64     `bson:"cplay_id"`
	AuthUsers             []int64   `bson:"auth_users"`
	AdminMode             AdminMode `bson:"admin_mode,omitempty"`
	Language              string    `bson:"language"`
	AssistantIndex        int       `bson:"ass_index,omitempty"`
	ThumbnailsDisabled    bool      `bson:"no_thumb"`
	PlayModeAdminsOnly    bool      `bson:"play_mode"`
	CommandDelete         bool      `bson:"cmd_delete"`
	CleanMode             bool      `bson:"clean_mode"`
	CleanModeDurationMins int       `bson:"clean_mode_duration_mins"`
	Autoplay              bool      `bson:"autoplay"`
}

func defaultChatSettings(chatID int64) *ChatSettings {
	return &ChatSettings{
		ChatID:                chatID,
		AuthUsers:             []int64{},
		CleanModeDurationMins: 15,
	}
}

func getChatSettings(chatID int64) (*ChatSettings, error) {
	if settings, found := chatSettingsCache.Get(chatID); found {
		return settings, nil
	}

	ctx, cancel := ctx()
	defer cancel()

	var settings ChatSettings
	err := chatSettingsColl.FindOne(ctx, bson.M{"_id": chatID}).
		Decode(&settings)

	if err == mongo.ErrNoDocuments {
		def := defaultChatSettings(chatID)
		chatSettingsCache.Set(chatID, def)
		return def, nil
	}

	if err != nil {
		return nil, fmt.Errorf(
			"failed to get chat settings for %d: %w",
			chatID,
			err,
		)
	}

	chatSettingsCache.Set(chatID, &settings)
	return &settings, nil
}

func updateChatSettings(settings *ChatSettings) error {
	ctx, cancel := ctx()
	defer cancel()

	_, err := chatSettingsColl.UpdateOne(
		ctx,
		bson.M{"_id": settings.ChatID},
		bson.M{"$set": settings},
		upsertOpt,
	)
	if err != nil {
		return fmt.Errorf(
			"failed to update chat settings for %d: %w",
			settings.ChatID,
			err,
		)
	}

	chatSettingsCache.Set(settings.ChatID, settings)
	return nil
}

func GetChatSettings(chatID int64) (*ChatSettings, error) {
	return getChatSettings(chatID)
}

func UpdateChatSettings(settings *ChatSettings) error {
	return updateChatSettings(settings)
}

func modifyChatSettings(chatID int64, fn func(*ChatSettings) bool) error {
	settings, err := getChatSettings(chatID)
	if err != nil {
		return err
	}

	if fn(settings) {
		return updateChatSettings(settings)
	}

	return nil
}

// Autoplay reports whether autoplay is persistently enabled for the chat.
func Autoplay(chatID int64) (bool, error) {
	s, err := getChatSettings(chatID)
	if err != nil {
		return false, err
	}
	return s.Autoplay, nil
}

// SetAutoplay updates the persistent autoplay setting for the chat.
func SetAutoplay(chatID int64, enabled bool) error {
	return modifyChatSettings(chatID, func(s *ChatSettings) bool {
		if s.Autoplay == enabled {
			return false
		}
		s.Autoplay = enabled
		return true
	})
}
